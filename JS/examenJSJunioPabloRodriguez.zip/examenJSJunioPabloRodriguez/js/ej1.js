let correctas=0;
let incorrectas=0;


let numRespuestas=()=>{

    let p=document.getElementById("seleccion");

    let opcion=p.options[p.selectedIndex].value;

    //opcion='madrid'? correctas++:incorrectas++;

    if(opcion=='madrid'){
        correctas++;
    }else{
        incorrectas++;
    }

    let n=document.getElementById("numero");

    n.textContent=`Numero de respuestas correctas:${correctas}, Numero de respuestas incorrectas:${incorrectas}`;

    correctas>=2? document.body.style.backgroundColor='green':document.body.style.backgroundColor='red';
}


let limpiar=()=>{
    let n=document.getElementById("numero");

    n.textContent='';

}