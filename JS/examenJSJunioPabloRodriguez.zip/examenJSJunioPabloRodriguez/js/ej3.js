const enlaces=new Map();

enlaces.set("yahoo","https://www.yahoo.es");
enlaces.set("google","https://www.google.es");



let cadena='<select id="seleccion">';
for([clave,elemento] of enlaces){
    cadena+=`<option value="clave">${clave}</option>`;
} 
cadena+='</select>';
document.getElementById("resultado").innerHTML=cadena;



//let s=document.getElementById("seleccion");
//let opcion=s.options[s.selectedIndex].value;


    //opcion=='google'? window.location='https://www.google.es':window.location= 'https://www.yahoo.es';

   

