let v=screen.availWidth();
let mayorTamañoPantalla=()=>{

    v+=10;
    let ventana1=window.open('','',`width:${v},height=${screen.availHeight}`);
    return v;
}

let menorTamañoPantalla=()=>{
    v-=10;
    let ventana2=window.open('','',`width:${v},height=${screen.availHeight}`);
    return v;
}