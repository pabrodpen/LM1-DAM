let cargarVector1=()=>{
    let n=prompt('Longitud del primer vector:');
    let v1=new Array(n);

    for(let i=0;i<n;i++){
        v1[i]=prompt('Dime una palabra para el primer vector:');
    }
    return v1;
}

let cargarVector2=(vector)=>{
    let v2=new Array(vector.length);

    for(let i=0;i<vector.length;i++){
        v2[i]=prompt('Dime una palabra para el segundo vector:');
    }
    return v2;
}

let MayusV=(arr)=>{
    let aux=arr.map(function(elemento){
        return elemento.toUpperCase();
    });

    return aux;
}


let sumaLongitudes=(arr1,arr2)=>{
    let resultado=new Array(arr1.length);

    let j=arr2.length-1;
    for(let i=0;i<arr1.length;i++){
        resultado[i]=parseInt(arr1[i].length) + parseInt(arr2[j].length);
        j--;
    }
    return resultado;
}



let lista1=cargarVector1();
let lista2=cargarVector2(lista1);

let lista1Mayus=MayusV(lista1);
let lista2Mayus=MayusV(lista2);

document.write(`Lista 1 en mayusculas: ${lista1Mayus}`);
document.write('<br>');
document.write(`Lista 2 en mayusculas: ${lista2Mayus}`);
document.write('<br>');

let suma=sumaLongitudes(lista1Mayus,lista2Mayus);
document.write(`Lista de suma de longitudes: ${suma}`);
