const enlaces = new Map();
  enlaces.set("google", "https://www.google.es");
  enlaces.set("yahoo", "https://www.yahoo.es");
  enlaces.set("youtube", "https://www.youtube.es");
  enlaces.set("gmail", "https://gmail.com");

  function cargaPestaña(nombre) {
    for (let [sitio, enlace] of enlaces) {
      if (sitio == nombre) {
        window.location.href = enlace;
      }
    }
  }