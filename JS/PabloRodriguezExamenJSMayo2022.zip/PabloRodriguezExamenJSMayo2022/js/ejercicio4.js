let variable=screen.availWidth/2;

function v1(){
    let ventana1= window.open(`width=${variable}+10`);
}

function v2(){
    let ventana2=window.open(`width=${variable}-10`);
}
