
let n;
let lista1 = (n) => {
  let v1 = new Array(n);
  for (let i = 0; i < v1.length; i++) {
    v1[i] = parseInt(prompt('Dime un numero:'));
  }
  return v1;
}

const v1 = lista1(3);

let lista2 = v1.map(function(element) {
  return parseInt(element + 1);
});

let listaAux = lista2.map(function(element, indice) {
  return parseInt(element + v1[indice]);
});

let lista3 = listaAux.map(function(element, indice) {
  return parseInt(element + lista2[indice]);
});

for (let numero of lista3) {
  document.write(numero);
}
