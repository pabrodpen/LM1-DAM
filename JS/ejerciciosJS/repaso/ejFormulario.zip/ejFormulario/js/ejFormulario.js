function verificarRespuestas() {
    let correctas = 0;
    let incorrectas = 0;

    let select = document.getElementById("respuestas");
    let opcionSeleccionada = select.options[select.selectedIndex].value;

    if (opcionSeleccionada === "b") {
      correctas++;
    } else {
      incorrectas++;
    }

    alert("Respuestas correctas: " + correctas + "\nRespuestas incorrectas: " + incorrectas);
  }